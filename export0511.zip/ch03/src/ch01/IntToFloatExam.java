package ch01;

public class IntToFloatExam {
	public static void main(String[] args) {
		float num1 = 123456780f;
		System.out.printf("%f",num1);
		System.out.printf("\n");
		double num2 = 123456780;
		System.out.printf("%f\n", num2);
		
		System.out.printf("%f\n",10.0);
		System.out.printf("%d\n",10);
		System.out.printf("%s", "hello");
		
	}
}
