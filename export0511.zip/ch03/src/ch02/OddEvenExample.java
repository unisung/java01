package ch02;

public class OddEvenExample {
	public static void main(String[] args) {
		int i=10;
		
		if(i%2==0) {
			System.out.println("¦��");
		}else {
			System.out.println("Ȧ��");
		}
	}
}
