package ch03;
//byteŸ�԰��� �����÷ο� 
public class ByteExam {
	public static void main(String[] args) {
		byte b=127;
		
		for(int i=0;i<300;i++) {
			System.out.println(b);
			b++;//b=b+1
		}
	}

}
