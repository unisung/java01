package ch03;

public class WrapperRangeExam {
public static void main(String[] args) {
System.out.println(Byte.MIN_VALUE+"<=Byte����<="+Byte.MAX_VALUE);
System.out.println(Short.MIN_VALUE+"<=Short����<="+Short.MAX_VALUE);
System.out.println(Integer.MIN_VALUE+"<=Int����<="+Integer.MAX_VALUE);
System.out.println(Long.MIN_VALUE+"<=Long����<="+Long.MAX_VALUE);
System.out.println(Double.MIN_VALUE+"<=Double����<="+Double.MAX_VALUE);

	}

}
