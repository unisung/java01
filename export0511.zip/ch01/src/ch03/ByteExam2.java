package ch03;
//byte Ÿ�� -128~127
public class ByteExam2 {
	public static void main(String[] args) {
		byte var1 = -128;
		byte var2=-30;
		byte var3=0;
		byte var4=30;
		byte var5=127;
		//byte var6=128;// byteŸ���ǹ��� -128~127,
		
		System.out.println(var1);
		System.out.println(var2);
		System.out.println(var3);
		System.out.println(var4);
		System.out.println(var5);
	}
}
