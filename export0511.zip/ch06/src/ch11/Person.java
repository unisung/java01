package ch11;

public class Person {
    //final �ʵ�� =>���
	final String nation="korea";
	final String ssn;
	String name;
	
	public Person(String ssn,String name) {
		this.ssn=ssn;
		this.name=name;
	}
}
