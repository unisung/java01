package ch01;

public class Handle {
	//�Ӽ�
	String rotation;
	//���
	public void turn(String rotation) {
		this.rotation=rotation;
	}
	//���
	public String getTurn() {
		return rotation;
	}
	

}
