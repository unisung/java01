package ch01;

public class CarMainExample {
 public static void main(String[] args) {
  Car car1 = new Car();
  

	}

}
