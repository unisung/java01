package ch01;

public class Engine {
  int cc;
  Engine(){
	  cc=2000;
  }
  
}
