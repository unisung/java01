package ch02;

public enum Gender {
 MALE,FEMALE
}
