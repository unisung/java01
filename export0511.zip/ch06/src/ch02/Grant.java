package ch02;

public enum Grant {
 ADMIN,GUEST
}
