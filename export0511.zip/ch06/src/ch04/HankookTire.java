package ch04;

public class HankookTire extends Tire {

}
