package ch04;

public class Tire {

}
