package ch04;

public class KeumhoTire extends Tire {

}
