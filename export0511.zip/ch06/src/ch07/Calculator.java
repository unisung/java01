package ch07;

public class Calculator {
	// plus(int, int)
  int plus(int x, int y) {
	  return x+y;
  }
  //plus(double,double)
  double plus(double x, double y) {
	  return x+y;
  }
  //���� plus(int,int)
  //int plus(int boonja, int boonmo) {
	//  return boonja+boonmo;
  //}
}
