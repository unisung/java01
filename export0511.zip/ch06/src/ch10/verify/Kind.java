package ch10.verify;

public enum Kind {
Sedan, Suv, Truck
}
