package ch10.verify;

public class Car {
	
	String kind;//sedan, truck, suv
	int inTime;
	int outTime;
	//������
	public Car(String kind, int inTime) {
		this.kind = kind;
		this.inTime = inTime;
	}
	public int getOutTime() {
		return outTime;
	}
	public void setOutTime(int outTime) {
		this.outTime = outTime;
	}
	
	
	
	
	
	
	
	

}
