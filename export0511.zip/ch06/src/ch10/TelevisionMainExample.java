package ch10;

public class TelevisionMainExample {
	public static void main(String[] args) {
		Television tv = new Television();
		System.out.println(tv);
	}
}
