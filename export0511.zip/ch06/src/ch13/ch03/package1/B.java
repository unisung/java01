package ch13.ch03.package1;

public class B {
	//�ɹ� -public
	public int n;
	public void g() {
		n=5;
	}
}
