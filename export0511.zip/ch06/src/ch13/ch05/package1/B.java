package ch13.ch05.package1;

//Ŭ���� -public
public class B {
 //�ɹ� - default
  int n;
  void g() {
	  n=5;
  }
}
