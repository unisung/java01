package ch13.ch02.package1;

public class B {
  A a=new A();
}
