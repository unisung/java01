package ch13.ch02.package1;

public class A {
  B b=new B();
}
