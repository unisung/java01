package ch13.ch04.package1;
//Ŭ����-public
public class B {
  //�ɹ� - private
	private int n;
	private void g() {
		n=5;
	}
}
