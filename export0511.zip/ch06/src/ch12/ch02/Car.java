package ch12.ch02;

public class Car {

}
