package ch12.kumho;
public class KumhoTire {
	public KumhoTire(){}
}
