package ch03;

public class VehicleMainExample {
	public static void main(String[] args) {
		Car car = new Car();
		car.speedUp();
		car.run();
		car.stop();
		car.speedUp();
		car.speedUp();
		car.speedUp();
		car.speedUp();
		car.speedUp();
		car.speedUp();
		car.getSpeed();

		Car2 car2 = new Car2();
		car2.speedUp();
		car2.run();
		car2.stop();
		car2.speedUp();
		car2.speedUp();
		car2.speedUp();
		car2.speedUp();
		car2.speedUp();
		car2.speedUp();
		car2.speedUp();
		car2.getSpeed();
	}

}
