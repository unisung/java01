package ch05;

public class CarMainExample {

	public static void main(String[] args) {
		Car c1 = new Car();
		Car c2;
		c2=new Car();
		System.out.println("hello");
	}
}
