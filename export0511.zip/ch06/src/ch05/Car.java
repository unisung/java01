package ch05;

public class Car {
	public static void main(String[] args) {
		System.out.println("Car");
	}
}
