package ch05.ch06;

public class MemberMainExample {

	public static void main(String[] args) {
		Member m=new Member("hong","ȫ�浿","1234","�����","010-111-1234","hong@daum.net");

	}

}
