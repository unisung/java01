package ch05.ch06.verify;

public enum Brix {
LOW,MEDIUM,HIGH
}
