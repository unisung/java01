package ch05.ch06;

public class AMainExample {
public static void main(String[] args) {
 A a = 
 new A("hello","hi",10);		

 A a2=new A();
 
	}
}
