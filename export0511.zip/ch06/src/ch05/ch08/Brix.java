package ch05.ch08;

public enum Brix {
LOW,MEDIUM,HIGH
}
