package ch05.ch08;

public class A extends Object {

}
