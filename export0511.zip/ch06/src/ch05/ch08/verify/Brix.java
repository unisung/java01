package ch05.ch08.verify;

public enum Brix {
LOW,MEDIUM,HIGH
}
