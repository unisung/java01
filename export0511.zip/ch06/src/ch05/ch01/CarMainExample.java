package ch05.ch01;

public class CarMainExample {
	public static void main(String[] args) {
		Car car=new Car();
		System.out.println(car.company);
		
		System.out.println(car.maxSpeed);
		System.out.println(car.speed);
		
		System.out.println(car.body);
		System.out.println(car.tire);
		
		System.out.println(car.siStop);
		

	}

}
