package ch05.ch02;

public class CarMainExample {
	public static void main(String[] args) {
		Car car = new Car();
	}

}
