package ch05.ch07;

public enum Brix {
LOW,MEDIUM,HIGH
}
