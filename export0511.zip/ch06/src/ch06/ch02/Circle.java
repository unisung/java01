package ch06.ch02;

public class Circle {
	int radius;

	public Circle(int radius) {
		this.radius = radius;
	}

	public Circle() {}

	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}
	
	

	

}
