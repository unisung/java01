package ch06;

public class Person {
	String name;
	char Gender;
	int age;
	
	public Person(String name, char gender, int age) {
		this.name = name;
		Gender = gender;
		this.age = age;
	}
}
