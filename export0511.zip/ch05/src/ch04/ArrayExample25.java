package ch04;

public class ArrayExample25 {
	public static void main(String[] args) {
		System.out.println(args.length);
		//String strArray= {};
		System.out.println(args[0]);
		System.out.println(args[1]);
	}
}
