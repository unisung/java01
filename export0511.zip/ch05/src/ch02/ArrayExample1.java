package ch02;

public class ArrayExample1 {
	public static void main(String[] args) {
		int sum=0;
		int score1=10;
		sum+=score1;
		int score2=20;
		sum+=score2;
		int score3=20;
		sum+=score3;
		int score4=20;
		sum+=score4;
		int score5=20;
		sum+=score5;
		int score6=20;
		sum+=score6;
		
		double avg=sum/6;
		System.out.println("���:"+avg);
		
		
		
		

	}

}
