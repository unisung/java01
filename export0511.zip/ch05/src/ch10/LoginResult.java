package ch10;

public enum LoginResult {
 LOGIN_SUCCESS, LOGIN_FAILED
}
