package ch02;

public class ForExample5 {

	public static void main(String[] args) {
		//int sum=0;
		for(int i=1,sum=0;i<=10;i++,System.out.println("sum="+sum)) {
			sum=sum+i;
		}
	}
}