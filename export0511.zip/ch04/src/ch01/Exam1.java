package ch01;

public class Exam1 {
	public static void main(String[] args) {
		int a=-10;
		
		 ++a;
		 a--;
		int result = -a;
		System.out.println(result);
		
		result = 10+20;
		System.out.println(result);
		
		

	}

}
