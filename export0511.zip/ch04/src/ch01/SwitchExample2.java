package ch01;

public class SwitchExample2 {
	public static void main(String[] args) {
		int time =10;
		
		switch(time) {
		case 7:System.out.println("���");
		case 8:System.out.println("�Ļ�");
		case 9:System.out.println("���");
		case 10:System.out.println("ȸ��");
		case 11:System.out.println("����");
		case 12:System.out.println("����");
		default:System.out.println("�ٹ�");
		}

	}

}
