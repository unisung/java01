package ch01;

public class Parent1 {

}
